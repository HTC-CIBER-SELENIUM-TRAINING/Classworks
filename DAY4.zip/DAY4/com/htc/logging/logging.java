package com.htc.logging;



import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class logging {


	    public static void main(String[] args) {
	         // TODO Auto-generated method stub
	    	
	    	String log4jConfPath = "D:\\CoreJavaCiberWorkSpace\\Day-4\\log4j.properties";
	    	PropertyConfigurator.configure(log4jConfPath);
	        
	         //Logger log = Logger.getLogger("devpinoyLogger");
	         Logger log = Logger.getLogger("myLogger");
	        
	         log.debug("entring weight");
			 log.info("opening webiste");
			 
	         log.warn("Test warN");
	         log.error("Test error log");
	         log.fatal("Tets fatal");
	       
			 
			
		}
	}

