package com.htc.checkedunchecked;
//Unchecked are the exceptions that are not checked at compiled time.
//In Java exceptions under Error and RuntimeException classes are unchecked exceptions, everything else under throwable is checked.
public class UncheckedExample {
	
		   public static void main(String args[]) {
		      int x = 0;
		      int y = 10;
		      try
		      {
		      int z = y/x;}
		      catch(ArithmeticException e){
		    	  System.out.println(e.getMessage());
		    	  e.printStackTrace();
		      }
		      System.out.println("Program execution contuinues");
		  }
		}
