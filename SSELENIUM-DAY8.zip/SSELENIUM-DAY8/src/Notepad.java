
import java.io.IOException;
import java.net.URL;

import org.junit.Test;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;

public class Notepad {
 @Test
 public void test() throws IOException{
  DesktopOptions options= new DesktopOptions();
  options.setApplicationPath("C:\\WINDOWS\\system32\\notepad.exe");
  try{
   WiniumDriver driver=new WiniumDriver(new URL("http://localhost:9999"),options);
  WebElement textaread= driver.findElementByClassName("Edit");
  textaread.sendKeys("Hello");
   driver.close();
  }
  catch(Exception e){
   System.out.println(e.getMessage());
  }
 }
}