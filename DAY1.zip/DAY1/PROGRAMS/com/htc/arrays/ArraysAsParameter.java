package com.htc.arrays;

public class ArraysAsParameter {
	 // Driver method
    public static void main(String args[]) 
    {
        int arr[] = {3, 1, 2, 5, 4};
         
        // passing array to method m1
        System.out.println("Sum form the main"+ sum(arr));
     
    }
 
    public static int sum(int[] arr) 
    {
        // getting sum of array values
        int sum = 0;
         
        for (int i = 0; i < arr.length; i++)
            sum+=arr[i];
         
        System.out.println("sum of array values : " + sum);
		return sum;
    }
}
