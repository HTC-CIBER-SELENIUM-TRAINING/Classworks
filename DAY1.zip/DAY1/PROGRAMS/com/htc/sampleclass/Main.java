package com.htc.sampleclass;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Calling the parameterized constructor
       Person obj=new Person("Sam", 25, 'm', "kjhskhsh","Developer", "o");//creating person object
       System.out.println(obj);
       //Calling the default constructor
       Person obj2=new Person();
       System.out.println(obj2);
       Person obj3=new Person();
       obj3.setName("John");
       obj3.setAge(30);
       System.out.println(obj3);
       System.out.println(obj3.getAddress());
       Person []objarray=new Person[10];
       for (int i =0;i<objarray.length;i++)
       { objarray[i]=new Person();
    	   System.out.println(objarray[i]);}
       	}

}
