package com.htc.example;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;

public class GoogleScenario {
	

	public static WebDriver driver;
@Given("^launch Chrome and start application$")
public void launch_Chrome_and_start_application() throws InterruptedException  {
	 System.setProperty("webdriver.chrome.driver","D:\\SELENIUMjars\\chromelatest\\chromedriver.exe");
	 driver=new ChromeDriver();
	 String baseUrl="https://www.google.com";
	 driver.get(baseUrl);
	// driver.manage().window().maximize();
	 			
}

@When("^enter text in the search box$")
public void enter_text_in_the_search_box() throws InterruptedException  {
	String tbxp="//*[@id='lst-ib']";
	 Thread.sleep(3000);
	WebElement search=driver.findElement(By.xpath(tbxp));
	search.sendKeys("Apple");
	search.submit();
	
}

@Then("^search images relevant to the search$")
public void search_images_relevant_to_the_search() throws InterruptedException  {
	String applexp="//*[@id='hdtb-msb-vis']/div[3]/a";
	driver.findElement(By.xpath(applexp)).click();
	Thread.sleep(1000);
	driver.quit();
}


}
