package com.htc.calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.htc.selenium.drivers.WebDriversFactory;

public class CalendarControlDemo {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = WebDriversFactory.getWebdriver();
		driver.get("https://demos.devexpress.com/aspxeditorsdemos/ASPxCalendar/Features.aspx");

		// Date value "21/12/2017"

		// Element to change month and year
		WebElement calendarContent = driver.findElement(By.xpath("//*[@id=\"ContentHolder_calendar_T\"]"));
		
		calendarContent.click(); // Months
		Thread.sleep(2000);

		calendarContent.click(); // Years
		Thread.sleep(2000);
/*
		WebElement yearValue = driver.findElement(By.xpath("//*[@id=\"ContentHolder_calendar_FN_I8\"]"));
		yearValue.click(); // Selecting year 2017
		Thread.sleep(2000);

		WebElement monthValue = driver.findElement(By.xpath("//*[@id=\"ContentHolder_calendar_FN_I11\"]"));
		monthValue.click(); // Selecting December month
		Thread.sleep(2000);

		WebElement dayValue = driver.findElement(By.xpath("//*[@id=\"ContentHolder_calendar_mt\"]/tbody/tr[5]/td[6]"));
		dayValue.click(); // Selecting Day 21
*/
		
		// Date value "06/01/2019"
		
		WebElement yearValue = driver.findElement(By.xpath("//*[@id=\"ContentHolder_calendar_FN_I10\"]"));

		yearValue.click(); // Selecting year 2019
		Thread.sleep(2000);

		WebElement monthValue = driver.findElement(By.xpath("//*[@id=\"ContentHolder_calendar_FN_I0\"]"));
	
		monthValue.click(); // Selecting Jan month
		Thread.sleep(2000);

		WebElement dayValue = driver.findElement(By.xpath("//*[@id=\"ContentHolder_calendar_mt\"]/tbody/tr[3]/td[2]"));
	
		
		dayValue.click(); // Selecting Day 06


		
		
		
	}
}