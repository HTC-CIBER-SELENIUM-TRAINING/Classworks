package testng;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;


// Implements   ITestListener
// extends      TestListenerAdapter

public class SimpleTestReportListener extends TestListenerAdapter{
	
	HSSFWorkbook book;
	HSSFSheet sheet;
	int rowCount = 0;
	int cellCount = 0;
	Row reportRow;
	
	@Override //suite starts
	public void onStart(ITestContext tc) {
		book = new HSSFWorkbook();
		sheet = book.createSheet("testreports");
		reportRow = sheet.createRow(rowCount++);
		
		Cell methodName = reportRow.createCell(cellCount++,CellType.STRING);
		methodName.setCellValue("Method Name");
		Cell status = reportRow.createCell(cellCount++,CellType.STRING);
		status.setCellValue("Test Status");
		Cell startTime = reportRow.createCell(cellCount++,CellType.STRING);
		startTime.setCellValue("Start Time");
		Cell endTime = reportRow.createCell(cellCount++,CellType.STRING);
		endTime.setCellValue("End Time");
		Cell diffTime = reportRow.createCell(cellCount++,CellType.STRING);
		diffTime.setCellValue("Elapsed");

		Cell errorMessage = reportRow.createCell(cellCount++,CellType.STRING);
		errorMessage.setCellValue("Error Message");
	}

	@Override
	public void onTestFailure(ITestResult tr) {
		
		Cell testNamecell = reportRow.createCell(cellCount++, CellType.STRING);
		testNamecell.setCellValue(tr.getMethod().getMethodName());

		Cell testStatuscell = reportRow.createCell(cellCount++, CellType.STRING);
		testStatuscell.setCellValue("FAILURE");

		Cell testStartTimecell = reportRow.createCell(cellCount++, CellType.STRING);
		long startTime = tr.getStartMillis();
		Date startdate = new Date(startTime);
		SimpleDateFormat sd = new SimpleDateFormat("HH:mm:ss");
		testStartTimecell.setCellValue(sd.format(startdate));

		Cell testendTimeCell = reportRow.createCell(cellCount++, CellType.STRING);
		long endTime = tr.getEndMillis();
		Date enddate = new Date(endTime);
		SimpleDateFormat sd1 = new SimpleDateFormat("HH:mm:ss");
		testendTimeCell.setCellValue(sd.format(enddate));

		Cell testTimeDiffCell = reportRow.createCell(cellCount++, CellType.STRING);
		long timeDiff = endTime - startTime;
		testTimeDiffCell.setCellValue(timeDiff +" ms");

		Cell testExcell = reportRow.createCell(cellCount++, CellType.STRING);
		testExcell.setCellValue(tr.getThrowable().toString());
	}

	@Override
	public void onTestSkipped(ITestResult tr) {
		cellCount=0;
		reportRow = sheet.createRow(rowCount++);

		Cell testNamecell = reportRow.createCell(cellCount++, CellType.STRING);
		testNamecell.setCellValue(tr.getMethod().getMethodName());

		Cell testStatuscell = reportRow.createCell(cellCount++, CellType.STRING);
		testStatuscell.setCellValue("SKIPPED");

		Cell testStartTimecell = reportRow.createCell(cellCount++, CellType.STRING);
		long startTime = tr.getStartMillis();
		Date startdate = new Date(startTime);
		SimpleDateFormat sd = new SimpleDateFormat("HH:mm:ss");
		testStartTimecell.setCellValue(sd.format(startdate));

		Cell testendTimeCell = reportRow.createCell(cellCount++, CellType.STRING);
		long endTime = tr.getEndMillis();
		Date enddate = new Date(endTime);
		SimpleDateFormat sd1 = new SimpleDateFormat("HH:mm:ss");
		testendTimeCell.setCellValue(sd.format(enddate));

		Cell testTimeDiffCell = reportRow.createCell(cellCount++, CellType.STRING);
		long timeDiff = endTime - startTime;
		testTimeDiffCell.setCellValue(timeDiff +" ms");

		Cell testExcell = reportRow.createCell(cellCount++, CellType.STRING);
		testExcell.setCellValue(tr.getThrowable().toString());

	}

	@Override
	public void onTestStart(ITestResult tr) {
		reportRow = sheet.createRow(rowCount++);
		cellCount=0;
	}

	@Override
	public void onTestSuccess(ITestResult tr) {
		Cell testNamecell = reportRow.createCell(cellCount++, CellType.STRING);
		testNamecell.setCellValue(tr.getMethod().getMethodName());

		Cell testStatuscell = reportRow.createCell(cellCount++, CellType.STRING);
		testStatuscell.setCellValue("PASS");

		Cell testStartTimecell = reportRow.createCell(cellCount++, CellType.STRING);
		long startTime = tr.getStartMillis();
		Date startdate = new Date(startTime);
		SimpleDateFormat sd = new SimpleDateFormat("HH:mm:ss");
		testStartTimecell.setCellValue(sd.format(startdate));

		Cell testendTimeCell = reportRow.createCell(cellCount++, CellType.STRING);
		long endTime = tr.getEndMillis();
		Date enddate = new Date(endTime);
		SimpleDateFormat sd1 = new SimpleDateFormat("HH:mm:ss");
		testendTimeCell.setCellValue(sd.format(enddate));
		
		Cell testTimeDiffCell = reportRow.createCell(cellCount++, CellType.STRING);
		long timeDiff = endTime - startTime;
		testTimeDiffCell.setCellValue(timeDiff +" ms");
		
	}

	@Override
	public void onFinish(ITestContext tc) {
		// TODO Auto-generated method stub
		cellCount=0;
		reportRow = sheet.createRow(++rowCount);
		Cell cell1 = reportRow.createCell(cellCount++, CellType.STRING);
		cell1.setCellValue("Passed Test count:");

		Cell cell2 = reportRow.createCell(cellCount++, CellType.STRING);
		cell2.setCellValue(tc.getPassedTests().size());

		cellCount=0;
		reportRow = sheet.createRow(++rowCount);
		cell1 = reportRow.createCell(cellCount++, CellType.STRING);
		cell1.setCellValue("Failed Test count:");

		cell2 = reportRow.createCell(cellCount++, CellType.STRING);
		cell2.setCellValue(tc.getFailedTests().size());

		cellCount=0;
		reportRow = sheet.createRow(++rowCount);
		cell1 = reportRow.createCell(cellCount++, CellType.STRING);
		cell1.setCellValue("Skipped Test count:");

		cell2 = reportRow.createCell(cellCount++, CellType.STRING);
		cell2.setCellValue(tc.getSkippedTests().size());
		
		try {
			FileOutputStream fout = new FileOutputStream("testngreport.xls");
			book.write(fout);
			book.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
}
