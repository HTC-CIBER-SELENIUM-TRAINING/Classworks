package testng;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(SimpleTestReportListener.class)
//@Listeners(CustomTestRepoter.class)
//@Listeners(TestListernerinterfaceSample.class)
public class SampleTests {

	@Test
	public void testMethod1(){
		Assert.assertEquals("Page Title", "Page Title");
	}
	@Test
	public void testMethod2(){
		int value = 1;
		if(value==1)
			//throw new NullPointerException();
		Assert.assertEquals(true, true);
	}

	@Test(dependsOnMethods="testMethod2")
	public void testMethod3(){
		Assert.assertTrue(true);
	}

	@Test
	public void testMethod4(){
		Assert.assertTrue(true);
	}
	
	@Test
	public void testMethod5(){
		Assert.assertTrue(false);
	}
	@Test(dependsOnMethods="testMethod5")
	public void testMethod11()
	{
		Assert.assertEquals(true, false);
	}
	@Test
	public void testMethod6(){
		Assert.assertEquals(true, false);
	}

	@Test
	public void testMethod7(){
		Assert.assertEquals("message", "message");
	}
	
	@Test
	public void testMethod8(){
		int value = 2;
		if(value==2){
			//throw new NumberFormatException();
		}
		Assert.assertTrue(true);
	}
	
	@Test(dependsOnMethods="testMethod8")
	public void testMethod9(){
		
	}
	
	@Test(enabled=false)
	public void testMethod10(){
		Assert.assertEquals("message", "message");
		
	}

}
