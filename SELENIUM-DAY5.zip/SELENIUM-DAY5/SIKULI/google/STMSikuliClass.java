package google;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.Test;

import com.htc.selenium.drivers.WebDriversFactory;

public class STMSikuliClass {

	@Test
	public void facebookLogin() throws FindFailed{
		
	// Creating Object of 'Screen' class
	//Screen is a base class provided by Sikuli. It allows us to access all the methods provided by Sikuli.
	Screen screen = new Screen();
	// Creating Object of Pattern class and specify the path of specified images
	// I have captured images of Facebook Email id field, Password field and Login button and placed in my local directory
	// Facebook user id image 
	//Pattern username = new Pattern("img\\FacebookEmail.png");
	// Facebook password image
	//Pattern password = new Pattern("img\\FacebookPassword.png");
	// Facebook login button image
	Pattern login = new Pattern("\\src\\img\\signin.png");
	Pattern emailtextbox=new Pattern("\\src\\img\\googleemailtextbox.PNG") ;
	Pattern nextbutton=new Pattern("\\src\\img\\gmailnextbutton.PNG");
	WebDriver driver = WebDriversFactory.getWebdriver();
	// To maximize the browser
	//driver.manage().window().maximize() ;
	// Open Facebook
	driver.get("https://www.google.co.in/");
	screen.wait(login, 10);	 
	// Calling 'type' method to enter username in the email field using 'screen' object
	//screen.type(username, "testuser@gmail.com");
	// Calling the same 'type' method and passing text in the password field
	//screen.type(password, "testpassword");
	// This will click on login button
	screen.click(login);
	screen.wait(emailtextbox,10);
	screen.type(emailtextbox, "testuser@gmail.com");
	screen.wait(nextbutton,5);
	screen.click(nextbutton);
	
	}
 
}
